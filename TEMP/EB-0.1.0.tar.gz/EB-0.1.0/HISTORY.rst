.. :changelog:

History
-------

0.1.0 (ls)
---------------------

* First release on PyPI.
