#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
test_EB
----------------------------------

Tests for `EB` module.
"""

import unittest

from ensemblebuilder import ensemblebuilder


class TestEb(unittest.TestCase):

    def setUp(self):
        pass

    def test_something(self):
        pass

    def tearDown(self):
        pass
