# -*- coding: utf-8 -*-

__author__ = 'Rob Swift'
__email__ = 'robvswift@gmail.com'
__version__ = '0.1.0'
