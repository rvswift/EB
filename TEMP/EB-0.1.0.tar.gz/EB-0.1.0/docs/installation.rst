============
Installation
============

At the command line::

    $ easy_install EB

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv EB
    $ pip install EB
