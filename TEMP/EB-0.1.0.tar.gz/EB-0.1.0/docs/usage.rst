========
Usage
========

To use EB in a project::

    import EB
