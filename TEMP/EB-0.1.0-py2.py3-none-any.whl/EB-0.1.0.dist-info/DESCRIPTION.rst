===============================
EB
===============================

.. image:: https://img.shields.io/travis/rvswift/EB.svg
        :target: https://travis-ci.org/rvswift/EB

.. image:: https://img.shields.io/pypi/v/EB.svg
        :target: https://pypi.python.org/pypi/EB


Ensemble Builder

* Free software: BSD license
* Documentation: https://EB.readthedocs.org.

Features
--------

* TODO




History
-------

0.1.0 (ls)
---------------------

* First release on PyPI.


